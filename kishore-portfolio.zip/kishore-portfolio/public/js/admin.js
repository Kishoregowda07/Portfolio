/**
 * Admin Dashboard Controller
 * Fetches, filters, marks as read, replies to, and deletes contact form submissions.
 */

let allMessages = [];
let currentAdminKey = localStorage.getItem('kg-admin-key') || '';

document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const logoutBtn = document.getElementById('logout-btn');
  const refreshBtn = document.getElementById('refresh-btn');
  const searchInput = document.getElementById('search-input');

  if (currentAdminKey) {
    loadDashboard(currentAdminKey);
  }

  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const key = document.getElementById('admin-key-input').value.trim();
      if (key) {
        loadDashboard(key);
      }
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem('kg-admin-key');
      currentAdminKey = '';
      document.getElementById('dashboard-container').style.display = 'none';
      document.getElementById('login-container').style.display = 'block';
      document.getElementById('logout-btn').style.display = 'none';
      document.getElementById('admin-key-input').value = '';
    });
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      if (currentAdminKey) fetchMessages(currentAdminKey);
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      renderMessages(filterMessages(query));
    });
  }
});

async function loadDashboard(key) {
  const loginError = document.getElementById('login-error');
  loginError.style.display = 'none';

  try {
    const success = await fetchMessages(key);
    if (success) {
      currentAdminKey = key;
      localStorage.setItem('kg-admin-key', key);
      document.getElementById('login-container').style.display = 'none';
      document.getElementById('dashboard-container').style.display = 'block';
      document.getElementById('logout-btn').style.display = 'inline-block';
    } else {
      loginError.textContent = 'Invalid passkey. Default is kishore2026';
      loginError.style.display = 'block';
    }
  } catch (err) {
    loginError.textContent = 'Server connection error: ' + err.message;
    loginError.style.display = 'block';
  }
}

async function fetchMessages(key) {
  try {
    const res = await fetch(`/api/messages?key=${encodeURIComponent(key)}`);
    if (!res.ok) {
      return false;
    }
    const data = await res.json();
    if (data.success) {
      allMessages = data.messages || [];
      updateStats();
      renderMessages(allMessages);
      return true;
    }
    return false;
  } catch (err) {
    console.error('Fetch messages error:', err);
    return false;
  }
}

function updateStats() {
  const total = allMessages.length;
  const unread = allMessages.filter(m => m.status === 'unread').length;

  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-unread').textContent = unread;
}

function filterMessages(query) {
  if (!query) return allMessages;
  return allMessages.filter(m => 
    (m.name && m.name.toLowerCase().includes(query)) ||
    (m.email && m.email.toLowerCase().includes(query)) ||
    (m.subject && m.subject.toLowerCase().includes(query)) ||
    (m.message && m.message.toLowerCase().includes(query))
  );
}

function renderMessages(list) {
  const container = document.getElementById('messages-list');
  if (!container) return;

  if (list.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 4rem 1rem; color: var(--text-muted); background: var(--bg-card); border-radius: var(--radius-lg); border: 1px solid var(--border-subtle);">
        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">📭</div>
        <h3 style="font-size: 1.15rem; color: var(--text-primary); margin-bottom: 0.25rem;">No Inquiries Found</h3>
        <p style="font-size: 0.9rem;">No messages match your search or no messages have been submitted yet.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = list.map(m => {
    const isUnread = m.status === 'unread';
    const dateFormatted = new Date(m.created_at).toLocaleString();
    const mailtoLink = `mailto:${encodeURIComponent(m.email)}?subject=${encodeURIComponent('Re: ' + (m.subject || 'Your inquiry on my portfolio'))}&body=${encodeURIComponent('\n\n--- On ' + dateFormatted + ', ' + m.name + ' wrote:\n' + m.message)}`;

    return `
      <div class="msg-card ${isUnread ? 'unread' : ''}" id="msg-${m.id}">
        <div class="msg-card-top">
          <div>
            <div class="msg-sender-name">${escapeHtml(m.name)}</div>
            <a href="mailto:${escapeHtml(m.email)}" class="msg-sender-email">${escapeHtml(m.email)}</a>
          </div>
          <div style="text-align: right;">
            <div class="msg-date">${dateFormatted}</div>
            <span class="status-pill" style="font-size: 0.75rem; padding: 0.2rem 0.6rem; margin-top: 0.3rem;">
              ${isUnread ? '<span class="status-dot pulse" style="background:#ea580c;"></span> Unread' : '✓ Read'}
            </span>
          </div>
        </div>

        <div class="msg-subject">Subject: ${escapeHtml(m.subject || 'General Inquiry')}</div>
        <div class="msg-body">${escapeHtml(m.message)}</div>

        <div class="msg-actions">
          <a href="${mailtoLink}" class="btn btn-primary btn-sm">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
            Reply via Email
          </a>
          <button class="btn btn-secondary btn-sm" onclick="toggleReadStatus(${m.id}, '${isUnread ? 'read' : 'unread'}')">
            ${isUnread ? 'Mark as Read' : 'Mark as Unread'}
          </button>
          <button class="btn btn-danger btn-sm" onclick="deleteMessage(${m.id})">
            Delete
          </button>
        </div>
      </div>
    `;
  }).join('');
}

async function toggleReadStatus(id, newStatus) {
  try {
    const res = await fetch('/api/messages/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: currentAdminKey, id, status: newStatus })
    });
    if (res.ok) {
      const msg = allMessages.find(m => m.id === id);
      if (msg) msg.status = newStatus;
      updateStats();
      renderMessages(allMessages);
    }
  } catch (err) {
    alert('Failed to update status: ' + err.message);
  }
}

async function deleteMessage(id) {
  if (!confirm('Are you sure you want to delete this message permanently?')) return;
  try {
    const res = await fetch('/api/messages/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: currentAdminKey, id })
    });
    if (res.ok) {
      allMessages = allMessages.filter(m => m.id !== id);
      updateStats();
      renderMessages(allMessages);
    }
  } catch (err) {
    alert('Failed to delete message: ' + err.message);
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
}
