#!/usr/bin/env python3
"""
Kishore Gowda V - Portfolio Server & Contact Backend
Built with Python standard library (no external dependencies required).
Features:
- Static file serving for high-performance portfolio UI
- Robust /api/contact endpoint with SQLite persistence & JSON logging
- Optional automated SMTP email forwarding to kishore00007kumar@gmail.com
- Built-in /admin dashboard for Kishore to review messages
"""

import os
import sys
import json
import sqlite3
import mimetypes
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime

PORT = int(os.environ.get("PORT", 8080))
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "contacts.db")
LOG_PATH = os.path.join(DATA_DIR, "messages.jsonl")
ADMIN_KEY = os.environ.get("ADMIN_KEY", "kishore2026")
NOTIFY_EMAIL = os.environ.get("NOTIFY_EMAIL", "kishore00007kumar@gmail.com")
SMTP_SERVER = os.environ.get("SMTP_SERVER", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", 587))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PUBLIC_DIR, exist_ok=True)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contact_submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            subject TEXT,
            message TEXT NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            status TEXT DEFAULT 'unread',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(pattern, email.strip()) is not None

def send_email_notification(name, email, subject, message):
    if not (SMTP_SERVER and SMTP_USER and SMTP_PASS):
        print(f"[Contact Service] Notice: SMTP credentials not set. Message saved to SQLite DB and messages.jsonl.")
        return False
    try:
        msg = MIMEMultipart()
        msg['From'] = SMTP_USER
        msg['To'] = NOTIFY_EMAIL
        msg['Reply-To'] = email
        msg['Subject'] = f"[Portfolio Contact] {subject or 'New message from ' + name}"
        
        body = f"""
Hello Kishore,

You have received a new contact message through your portfolio website!

------------------------------------------------
From:    {name}
Email:   {email}
Subject: {subject or 'N/A'}
Date:    {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
------------------------------------------------

Message:
{message}

------------------------------------------------
You can reply directly to this email to contact {name} ({email}).
"""
        msg.attach(MIMEText(body, 'plain'))
        
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10)
        server.starttls()
        server.login(SMTP_USER, SMTP_PASS)
        server.send_message(msg)
        server.quit()
        print(f"[Contact Service] Notification email dispatched successfully to {NOTIFY_EMAIL}")
        return True
    except Exception as e:
        print(f"[Contact Service] Failed to send email via SMTP: {e}")
        return False

class PortfolioRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    def end_headers(self):
        # Enable CORS and disable overly aggressive caching for dynamic portfolio updates
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Key')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def send_json(self, status_code, data):
        payload = json.dumps(data, default=str).encode('utf-8')
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # API: Health check
        if path == "/api/health":
            self.send_json(200, {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "service": "Kishore Gowda Portfolio API"
            })
            return

        # API: Get messages (for Admin Dashboard)
        if path == "/api/messages":
            params = parse_qs(parsed.query)
            token = params.get("key", [""])[0] or self.headers.get("X-Admin-Key", "")
            if token != ADMIN_KEY:
                self.send_json(401, {"error": "Unauthorized. Provide valid admin key in query (?key=...) or X-Admin-Key header."})
                return

            try:
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, name, email, subject, message, ip_address, status, created_at 
                    FROM contact_submissions 
                    ORDER BY id DESC
                """)
                rows = cursor.fetchall()
                conn.close()

                messages = []
                for r in rows:
                    messages.append({
                        "id": r[0],
                        "name": r[1],
                        "email": r[2],
                        "subject": r[3],
                        "message": r[4],
                        "ip": r[5],
                        "status": r[6],
                        "created_at": r[7]
                    })
                self.send_json(200, {"success": True, "count": len(messages), "messages": messages})
            except Exception as e:
                self.send_json(500, {"error": str(e)})
            return

        # API: Message stats
        if path == "/api/stats":
            try:
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                cursor.execute("SELECT count(*) FROM contact_submissions")
                total = cursor.fetchone()[0]
                cursor.execute("SELECT count(*) FROM contact_submissions WHERE status = 'unread'")
                unread = cursor.fetchone()[0]
                conn.close()
                self.send_json(200, {"total_messages": total, "unread_messages": unread})
            except Exception as e:
                self.send_json(500, {"error": str(e)})
            return

        # Route /admin to admin.html
        if path == "/admin":
            admin_file = os.path.join(PUBLIC_DIR, "admin.html")
            if os.path.exists(admin_file):
                self.path = "/admin.html"
                return super().do_GET()

        # Fallback to standard static file server
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # API: Contact form submission
        if path == "/api/contact":
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length <= 0 or content_length > 65536: # 64KB max
                    self.send_json(400, {"success": False, "error": "Invalid request payload size."})
                    return

                raw_body = self.rfile.read(content_length).decode('utf-8')
                data = json.loads(raw_body)

                name = str(data.get("name", "")).strip()
                email = str(data.get("email", "")).strip()
                subject = str(data.get("subject", "")).strip() or "General Inquiry"
                message = str(data.get("message", "")).strip()

                if not name:
                    self.send_json(400, {"success": False, "error": "Please provide your name."})
                    return

                if not email or not is_valid_email(email):
                    self.send_json(400, {"success": False, "error": "Please provide a valid email address."})
                    return

                if not message or len(message) < 5:
                    self.send_json(400, {"success": False, "error": "Message is too short. Please write at least 5 characters."})
                    return

                client_ip = self.client_address[0]
                user_agent = self.headers.get('User-Agent', '')

                # 1. Save to SQLite database
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO contact_submissions (name, email, subject, message, ip_address, user_agent, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'unread')
                """, (name, email, subject, message, client_ip, user_agent))
                msg_id = cursor.lastrowid
                conn.commit()
                conn.close()

                # 2. Append to JSONL log
                log_entry = {
                    "id": msg_id,
                    "name": name,
                    "email": email,
                    "subject": subject,
                    "message": message,
                    "ip": client_ip,
                    "user_agent": user_agent,
                    "timestamp": datetime.now().isoformat()
                }
                with open(LOG_PATH, "a", encoding="utf-8") as f:
                    f.write(json.dumps(log_entry) + "\n")

                # 3. Trigger email notification in background/inline
                email_sent = send_email_notification(name, email, subject, message)

                self.send_json(200, {
                    "success": True,
                    "message": f"Thank you {name}! Your message has been received successfully. Kishore will get back to you at {email} as soon as possible.",
                    "id": msg_id,
                    "email_dispatched": email_sent
                })
            except json.JSONDecodeError:
                self.send_json(400, {"success": False, "error": "Invalid JSON in request body."})
            except Exception as e:
                print(f"[Error in /api/contact]: {e}")
                self.send_json(500, {"success": False, "error": f"Server error: {str(e)}"})
            return

        # API: Mark message as read
        if path == "/api/messages/read":
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                raw_body = self.rfile.read(content_length).decode('utf-8')
                data = json.loads(raw_body)
                token = data.get("key", "") or self.headers.get("X-Admin-Key", "")
                if token != ADMIN_KEY:
                    self.send_json(401, {"error": "Unauthorized."})
                    return

                msg_id = data.get("id")
                new_status = data.get("status", "read")
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                cursor.execute("UPDATE contact_submissions SET status = ? WHERE id = ?", (new_status, msg_id))
                conn.commit()
                conn.close()
                self.send_json(200, {"success": True, "id": msg_id, "status": new_status})
            except Exception as e:
                self.send_json(500, {"error": str(e)})
            return

        # API: Delete message
        if path == "/api/messages/delete":
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                raw_body = self.rfile.read(content_length).decode('utf-8')
                data = json.loads(raw_body)
                token = data.get("key", "") or self.headers.get("X-Admin-Key", "")
                if token != ADMIN_KEY:
                    self.send_json(401, {"error": "Unauthorized."})
                    return

                msg_id = data.get("id")
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                cursor.execute("DELETE FROM contact_submissions WHERE id = ?", (msg_id,))
                conn.commit()
                conn.close()
                self.send_json(200, {"success": True, "deleted_id": msg_id})
            except Exception as e:
                self.send_json(500, {"error": str(e)})
            return

        self.send_json(404, {"error": "Not Found"})

def run():
    print(f"============================================================")
    print(f"  Kishore Gowda V - Portfolio & Contact Server")
    print(f"  Root Directory: {PUBLIC_DIR}")
    print(f"  Database Path:  {DB_PATH}")
    print(f"  Admin Passkey:  {ADMIN_KEY}")
    print(f"  Serving on:     http://localhost:{PORT}")
    print(f"  Admin Portal:   http://localhost:{PORT}/admin")
    print(f"============================================================")
    server = HTTPServer(("0.0.0.0", PORT), PortfolioRequestHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server gracefully...")
        server.server_close()

if __name__ == "__main__":
    run()
